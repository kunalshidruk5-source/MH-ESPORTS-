package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.BottomNavTab
import com.example.ui.MhEsportsViewModel
import com.example.ui.SubScreen
import com.example.ui.screens.CoinsScreen
import com.example.ui.screens.GameTournamentListScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.MatchesScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TournamentDetailsScreen
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

class MainActivity : ComponentActivity() {

    private val viewModel: MhEsportsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MhEsportsApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MhEsportsApp(viewModel: MhEsportsViewModel) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val currentSubScreen by viewModel.getActiveSubScreen().collectAsStateWithLifecycle()
    val allTournaments by viewModel.allTournaments.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val leaderboardPlayers by viewModel.leaderboardPlayers.collectAsStateWithLifecycle()
    val isRefreshingMatches by viewModel.isRefreshingMatches.collectAsStateWithLifecycle()
    val isRefreshingLeaderboard by viewModel.isRefreshingLeaderboard.collectAsStateWithLifecycle()
    val paymentScreenshotUri by viewModel.paymentScreenshotUri.collectAsStateWithLifecycle()
    val paymentSuccessTournament by viewModel.paymentSuccessDialogTournament.collectAsStateWithLifecycle()
    val uiMessage by viewModel.uiMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiMessage) {
        uiMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUiMessage()
        }
    }

    // Intercept back button if any sub-screen is active
    BackHandler(enabled = currentSubScreen != null) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkCharcoal,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            // Show bottom navigation bar only when on root tabs
            if (currentSubScreen == null) {
                NavigationBar(
                    modifier = Modifier
                        .testTag("bottom_nav_bar")
                        .windowInsetsPadding(WindowInsets.navigationBars),
                    containerColor = GamingSurface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == BottomNavTab.PLAY,
                        onClick = { viewModel.selectTab(BottomNavTab.PLAY) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = "Play",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "PLAY",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextWhite,
                            selectedTextColor = NeonRed,
                            indicatorColor = NeonRed,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_item_play")
                    )

                    NavigationBarItem(
                        selected = currentTab == BottomNavTab.MATCHES,
                        onClick = { viewModel.selectTab(BottomNavTab.MATCHES) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Matches",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "MATCHES",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextWhite,
                            selectedTextColor = NeonRed,
                            indicatorColor = NeonRed,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_item_matches")
                    )

                    NavigationBarItem(
                        selected = currentTab == BottomNavTab.LEADERBOARD,
                        onClick = { viewModel.selectTab(BottomNavTab.LEADERBOARD) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Leaderboard,
                                contentDescription = "Leaderboard",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "RANKS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextWhite,
                            selectedTextColor = GoldPrize,
                            indicatorColor = Color(0xFFB8860B),
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_item_leaderboard")
                    )

                    NavigationBarItem(
                        selected = currentTab == BottomNavTab.COINS,
                        onClick = { viewModel.selectTab(BottomNavTab.COINS) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Coins",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "COINS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextWhite,
                            selectedTextColor = GoldPrize,
                            indicatorColor = Color(0xFFB8860B),
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_item_coins")
                    )

                    NavigationBarItem(
                        selected = currentTab == BottomNavTab.PROFILE,
                        onClick = { viewModel.selectTab(BottomNavTab.PROFILE) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Profile",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "PROFILE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TextWhite,
                            selectedTextColor = NeonRed,
                            indicatorColor = NeonRed,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_item_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val sub = currentSubScreen) {
                is SubScreen.GameTournamentList -> {
                    GameTournamentListScreen(
                        game = sub.game,
                        tournaments = allTournaments,
                        onBackClick = { viewModel.navigateBack() },
                        onTournamentClick = { id -> viewModel.openTournamentDetails(id) },
                        onJoinMatchClick = { id -> viewModel.openPaymentScreen(id) }
                    )
                }

                is SubScreen.TournamentDetails -> {
                    val tournament = allTournaments.find { it.id == sub.tournamentId }
                    if (tournament != null) {
                        TournamentDetailsScreen(
                            tournament = tournament,
                            onBackClick = { viewModel.navigateBack() },
                            onJoinMatchClick = { viewModel.openPaymentScreen(tournament.id) }
                        )
                    }
                }

                is SubScreen.Payment -> {
                    val tournament = allTournaments.find { it.id == sub.tournamentId }
                    if (tournament != null) {
                        PaymentScreen(
                            tournament = tournament,
                            userProfile = userProfile,
                            paymentScreenshotUri = paymentScreenshotUri,
                            onScreenshotUploaded = { uri -> viewModel.setPaymentScreenshotUri(uri) },
                            onCustomQrUploaded = { uri -> viewModel.updateCustomQr(uri) },
                            onPayWithCoinsClick = { viewModel.joinTournamentDirectlyWithCoins(tournament.id) },
                            onPaymentDoneClick = { viewModel.submitTournamentPaymentDone(tournament.id) },
                            onBackClick = { viewModel.navigateBack() }
                        )
                    }
                }

                is SubScreen.Settings -> {
                    SettingsScreen(
                        onBackClick = { viewModel.navigateBack() }
                    )
                }

                null -> {
                    // Main Tabs
                    when (currentTab) {
                        BottomNavTab.PLAY -> {
                            HomeScreen(
                                tournaments = allTournaments,
                                userProfile = userProfile,
                                onSelectGame = { game -> viewModel.openGameTournaments(game) },
                                onTournamentClick = { id -> viewModel.openTournamentDetails(id) },
                                onJoinMatchClick = { id -> viewModel.openPaymentScreen(id) }
                            )
                        }

                        BottomNavTab.MATCHES -> {
                            MatchesScreen(
                                tournaments = allTournaments,
                                isRefreshing = isRefreshingMatches,
                                onRefresh = { viewModel.refreshMatches() },
                                onTournamentClick = { id -> viewModel.openTournamentDetails(id) },
                                onJoinClick = { id -> viewModel.openPaymentScreen(id) }
                            )
                        }

                        BottomNavTab.LEADERBOARD -> {
                            LeaderboardScreen(
                                players = leaderboardPlayers,
                                isRefreshing = isRefreshingLeaderboard,
                                onRefresh = { viewModel.refreshLeaderboard() }
                            )
                        }

                        BottomNavTab.COINS -> {
                            CoinsScreen(
                                userProfile = userProfile,
                                transactions = allTransactions,
                                onCustomQrUploaded = { uri -> viewModel.updateCustomQr(uri) },
                                onSubmitCoinPurchase = { amount, uri -> viewModel.submitCoinPurchase(amount, uri) }
                            )
                        }

                        BottomNavTab.PROFILE -> {
                            ProfileScreen(
                                userProfile = userProfile,
                                tournaments = allTournaments,
                                onUpdateProfile = { username, ffUid, bgmiId ->
                                    viewModel.updateProfile(username, ffUid, bgmiId)
                                },
                                onSettingsClick = { viewModel.openSettings() }
                            )
                        }
                    }
                }
            }
        }
    }

    // Payment Submitted Success Dialog
    if (paymentSuccessTournament != null) {
        val tournament = paymentSuccessTournament!!
        AlertDialog(
            onDismissRequest = { viewModel.dismissPaymentSuccessDialog() },
            containerColor = GamingSurface,
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = StatusGreen,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "MATCH JOINED / PAYMENT SUBMITTED",
                    color = TextWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp
                )
            },
            text = {
                androidx.compose.foundation.layout.Column(
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Tournament: ${tournament.title}",
                        color = GoldPrize,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Format: ${tournament.game} ${tournament.format} • Prize: ${tournament.winnerPrize}",
                        color = TextWhite,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Your submission is recorded for admin verification. Your custom match Room ID & Password are now unlocked in your Matches tab!",
                        color = TextMuted,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissPaymentSuccessDialog() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LockOpen,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.size(6.dp))
                    Text("VIEW ROOM CREDENTIALS", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
