package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CoinTransactionEntity
import com.example.data.model.TournamentEntity
import com.example.data.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MhEsportsDao {

    @Query("SELECT * FROM tournaments ORDER BY id ASC")
    fun getAllTournaments(): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments WHERE game = :game ORDER BY id ASC")
    fun getTournamentsByGame(game: String): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
    fun getTournamentById(id: String): Flow<TournamentEntity?>

    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
    suspend fun getTournamentByIdOnce(id: String): TournamentEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTournaments(tournaments: List<TournamentEntity>)

    @Update
    suspend fun updateTournament(tournament: TournamentEntity)

    @Query("UPDATE tournaments SET isJoined = 1, paymentStatus = :paymentStatus, screenshotUri = :screenshotUri, joinedAt = :joinedAt, currentPlayers = currentPlayers + 1 WHERE id = :id")
    suspend fun markTournamentJoined(id: String, paymentStatus: String, screenshotUri: String?, joinedAt: Long)

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getUserProfileOnce(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserProfile(profile: UserProfileEntity)

    @Query("UPDATE user_profile SET coinsBalance = :newBalance WHERE id = 1")
    suspend fun updateCoinsBalance(newBalance: Int)

    @Query("UPDATE user_profile SET customQrUri = :qrUri WHERE id = 1")
    suspend fun updateCustomQrUri(qrUri: String?)

    @Query("UPDATE user_profile SET username = :username, ffUid = :ffUid, bgmiId = :bgmiId WHERE id = 1")
    suspend fun updateProfileDetails(username: String, ffUid: String, bgmiId: String)

    @Query("SELECT * FROM coin_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<CoinTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: CoinTransactionEntity)

    @Query("SELECT COUNT(*) FROM tournaments")
    suspend fun getTournamentCount(): Int
}
