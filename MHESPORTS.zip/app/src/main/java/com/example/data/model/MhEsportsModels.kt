package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey val id: String,
    val game: String, // "FREE FIRE" or "BGMI"
    val format: String, // "1v1", "2v2", "4v4"
    val title: String,
    val entryCoins: Int = 10,
    val totalEntryCoins: Int,
    val winnerPrize: String,
    val maxPlayers: Int,
    val currentPlayers: Int = 0,
    val matchDate: String,
    val matchTime: String,
    val rules: String,
    val instructions: String,
    val regulations: String,
    val roomId: String,
    val roomPassword: String,
    val isJoined: Boolean = false,
    val paymentStatus: String = "NONE", // NONE, SUBMITTED, CONFIRMED
    val screenshotUri: String? = null,
    val joinedAt: Long? = null
)

@Entity(tableName = "coin_transactions")
data class CoinTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "USED", "RECEIVED"
    val amount: Int,
    val title: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "CONFIRMED", // "CONFIRMED", "PENDING_VERIFICATION"
    val referenceId: String = ""
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val username: String = "Kunal_Gamer",
    val playerId: String = "MH-77821",
    val ffUid: String = "FF-8392019",
    val bgmiId: String = "BGMI-5529104",
    val coinsBalance: Int = 50,
    val totalWins: Int = 3,
    val customQrUri: String? = null
)

data class LeaderboardPlayer(
    val id: String,
    val rank: Int,
    val username: String,
    val playerId: String,
    val game: String, // "FREE FIRE" or "BGMI"
    val wins: Int,
    val totalMatches: Int,
    val points: Int,
    val winRate: String,
    val earnings: String,
    val badgeTitle: String,
    val isCurrentUser: Boolean = false
)

