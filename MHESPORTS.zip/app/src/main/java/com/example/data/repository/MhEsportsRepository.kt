package com.example.data.repository

import com.example.data.local.MhEsportsDao
import com.example.data.model.CoinTransactionEntity
import com.example.data.model.LeaderboardPlayer
import com.example.data.model.TournamentEntity
import com.example.data.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MhEsportsRepository(private val dao: MhEsportsDao) {

    val allTournaments: Flow<List<TournamentEntity>> = dao.getAllTournaments()
    val userProfile: Flow<UserProfileEntity?> = dao.getUserProfile()
    val allTransactions: Flow<List<CoinTransactionEntity>> = dao.getAllTransactions()

    fun getTournamentsByGame(game: String): Flow<List<TournamentEntity>> =
        dao.getTournamentsByGame(game)

    fun getTournamentById(id: String): Flow<TournamentEntity?> =
        dao.getTournamentById(id)

    suspend fun seedInitialDataIfNeeded() {
        val count = dao.getTournamentCount()
        if (count == 0) {
            val initialTournaments = listOf(
                TournamentEntity(
                    id = "ff_1v1_01",
                    game = "FREE FIRE",
                    format = "1v1",
                    title = "FREE FIRE 1v1 Clash Royale",
                    entryCoins = 10,
                    totalEntryCoins = 20,
                    winnerPrize = "₹15",
                    maxPlayers = 2,
                    currentPlayers = 1,
                    matchDate = "Today",
                    matchTime = "08:00 PM IST",
                    rules = "1. Mobile devices only (No Emulators/Tablets allowed).\n2. Standard Bermudan Clash Squad map.\n3. Grenades and smoke spam prohibited.\n4. Screen recording recommended for score dispute.",
                    instructions = "1. Join the custom room 10 minutes prior to match time.\n2. Enter assigned slot.\n3. Submit final score screenshot if requested.\n4. Room details unlock after payment submission.",
                    regulations = "MH ESPORTS guarantees fair competition. In case of disconnection or hacks, report within 15 minutes to admin with video proof.",
                    roomId = "MH-FF101",
                    roomPassword = "7890"
                ),
                TournamentEntity(
                    id = "ff_2v2_01",
                    game = "FREE FIRE",
                    format = "2v2",
                    title = "FREE FIRE 2v2 Duo Showdown",
                    entryCoins = 10,
                    totalEntryCoins = 40,
                    winnerPrize = "₹40",
                    maxPlayers = 4,
                    currentPlayers = 2,
                    matchDate = "Today",
                    matchTime = "09:00 PM IST",
                    rules = "1. Mobile devices only.\n2. Duo squad clash.\n3. Character skills allowed.\n4. Teaming up with opponents results in immediate ban.",
                    instructions = "1. Both teammates must register with valid In-Game UIDs.\n2. Room opens 15 mins before match.\n3. Captain takes victory screenshot.",
                    regulations = "Prize money distributed directly to winner's registered UPI within 30 minutes of match completion.",
                    roomId = "MH-FF202",
                    roomPassword = "4321"
                ),
                TournamentEntity(
                    id = "ff_4v4_01",
                    game = "FREE FIRE",
                    format = "4v4",
                    title = "FREE FIRE 4v4 Squad Warfare",
                    entryCoins = 10,
                    totalEntryCoins = 80,
                    winnerPrize = "₹70",
                    maxPlayers = 8,
                    currentPlayers = 4,
                    matchDate = "Today",
                    matchTime = "10:00 PM IST",
                    rules = "1. Official 4v4 Custom Room rules apply.\n2. Strict anti-cheat policy.\n3. No third-party booster tools.",
                    instructions = "1. Team leader coordinates room entry.\n2. All 4 members must be ready 10 mins prior.\n3. Room password provided upon registration.",
                    regulations = "Winning team receives ₹70 prize. Verified by admin Kunal Shidruk.",
                    roomId = "MH-FF404",
                    roomPassword = "9911"
                ),
                TournamentEntity(
                    id = "bgmi_1v1_01",
                    game = "BGMI",
                    format = "1v1",
                    title = "BGMI 1v1 TDM Deathmatch",
                    entryCoins = 10,
                    totalEntryCoins = 20,
                    winnerPrize = "₹15",
                    maxPlayers = 2,
                    currentPlayers = 1,
                    matchDate = "Today",
                    matchTime = "08:30 PM IST",
                    rules = "1. Warehouse TDM (M416 / Beryl allowed).\n2. No slide option enabled as per standard scrim rules.\n3. First to reach 40 kills wins.\n4. Mobile phones only.",
                    instructions = "1. Room ID and password unlocked after join/payment.\n2. Join on time or face walkover forfeit.\n3. End-screen match stats mandatory.",
                    regulations = "Disputes reviewed by MH ESPORTS support within 15 minutes of completion.",
                    roomId = "MH-BG101",
                    roomPassword = "6655"
                ),
                TournamentEntity(
                    id = "bgmi_2v2_01",
                    game = "BGMI",
                    format = "2v2",
                    title = "BGMI 2v2 Duo Gunfight",
                    entryCoins = 10,
                    totalEntryCoins = 40,
                    winnerPrize = "₹40",
                    maxPlayers = 4,
                    currentPlayers = 2,
                    matchDate = "Today",
                    matchTime = "09:30 PM IST",
                    rules = "1. 2v2 TDM Warehouse or Erangel mini-zone.\n2. Armor level 2.\n3. Fair play strictly enforced.",
                    instructions = "1. Enter lobby when room is created.\n2. Ready up 5 minutes prior to match launch.",
                    regulations = "Cash prize ₹40 sent via UPI (kunalshidruk07@oksbii) immediately post-match.",
                    roomId = "MH-BG202",
                    roomPassword = "1122"
                ),
                TournamentEntity(
                    id = "bgmi_4v4_01",
                    game = "BGMI",
                    format = "4v4",
                    title = "BGMI 4v4 Squad Clash Championship",
                    entryCoins = 10,
                    totalEntryCoins = 80,
                    winnerPrize = "₹70",
                    maxPlayers = 8,
                    currentPlayers = 4,
                    matchDate = "Today",
                    matchTime = "10:30 PM IST",
                    rules = "1. Squad TDM / Custom Room Erangel match.\n2. Standard BGMI Esports competitive guidelines.\n3. Red zone active, classic tournament scoring.",
                    instructions = "1. Squad leader enters custom Room ID.\n2. Ensure all 4 players have verified BGMI Character IDs.",
                    regulations = "MH ESPORTS Admin decision is final. Prize ₹70 awarded to winning squad.",
                    roomId = "MH-BG404",
                    roomPassword = "8877"
                )
            )
            dao.insertTournaments(initialTournaments)
        }

        val profile = dao.getUserProfileOnce()
        if (profile == null) {
            dao.insertUserProfile(
                UserProfileEntity(
                    id = 1,
                    username = "Kunal_Gamer",
                    playerId = "MH-77821",
                    ffUid = "FF-8392019",
                    bgmiId = "BGMI-5529104",
                    coinsBalance = 50,
                    totalWins = 3,
                    customQrUri = null
                )
            )
            dao.insertTransaction(
                CoinTransactionEntity(
                    type = "RECEIVED",
                    amount = 50,
                    title = "Welcome Bonus Coins",
                    timestamp = System.currentTimeMillis() - 3600000,
                    status = "CONFIRMED",
                    referenceId = "WB-INIT-101"
                )
            )
        }
    }

    suspend fun joinTournamentWithCoins(tournamentId: String): Boolean {
        val profile = dao.getUserProfileOnce() ?: return false
        val tournament = dao.getTournamentByIdOnce(tournamentId) ?: return false

        if (profile.coinsBalance < tournament.entryCoins) {
            return false
        }

        // Deduct coins
        val newBalance = profile.coinsBalance - tournament.entryCoins
        dao.updateCoinsBalance(newBalance)

        // Mark tournament as joined and confirmed
        dao.markTournamentJoined(
            id = tournamentId,
            paymentStatus = "CONFIRMED",
            screenshotUri = null,
            joinedAt = System.currentTimeMillis()
        )

        // Add transaction
        dao.insertTransaction(
            CoinTransactionEntity(
                type = "USED",
                amount = tournament.entryCoins,
                title = "Entry Fee: ${tournament.game} ${tournament.format}",
                timestamp = System.currentTimeMillis(),
                status = "CONFIRMED",
                referenceId = "TXN-${System.currentTimeMillis() % 100000}"
            )
        )
        return true
    }

    suspend fun joinTournamentWithUpiSubmission(
        tournamentId: String,
        screenshotUri: String?
    ): Boolean {
        val tournament = dao.getTournamentByIdOnce(tournamentId) ?: return false

        // Mark tournament joined with status SUBMITTED (pending verification)
        dao.markTournamentJoined(
            id = tournamentId,
            paymentStatus = "SUBMITTED",
            screenshotUri = screenshotUri,
            joinedAt = System.currentTimeMillis()
        )

        // Add a record for UPI payment submission
        dao.insertTransaction(
            CoinTransactionEntity(
                type = "USED",
                amount = tournament.entryCoins,
                title = "UPI Payment Submitted: ${tournament.game} ${tournament.format}",
                timestamp = System.currentTimeMillis(),
                status = "PENDING_VERIFICATION",
                referenceId = "UPI-SUB-${System.currentTimeMillis() % 100000}"
            )
        )
        return true
    }

    suspend fun submitCoinPurchase(amount: Int, screenshotUri: String?) {
        val profile = dao.getUserProfileOnce()
        val currentBalance = profile?.coinsBalance ?: 0
        // For prototype usability, add coins to balance and record transaction
        val newBalance = currentBalance + amount
        dao.updateCoinsBalance(newBalance)

        dao.insertTransaction(
            CoinTransactionEntity(
                type = "RECEIVED",
                amount = amount,
                title = "Added $amount Coins via UPI Payment",
                timestamp = System.currentTimeMillis(),
                status = "CONFIRMED",
                referenceId = "UPI-ADD-${System.currentTimeMillis() % 100000}"
            )
        )
    }

    suspend fun updateCustomQrUri(uri: String?) {
        dao.updateCustomQrUri(uri)
    }

    suspend fun updateProfile(username: String, ffUid: String, bgmiId: String) {
        dao.updateProfileDetails(username, ffUid, bgmiId)
    }

    fun getLeaderboardPlayers(): Flow<List<LeaderboardPlayer>> {
        return userProfile.map { profile ->
            val userWins = profile?.totalWins ?: 3
            val userPoints = userWins * 120 + 350
            val currentUserName = profile?.username ?: "Kunal_Gamer"
            val currentUserPlayerId = profile?.playerId ?: "MH-77821"

            val basePlayers = listOf(
                LeaderboardPlayer(
                    id = "p1",
                    rank = 1,
                    username = "ViperStrike_FF",
                    playerId = "MH-99210",
                    game = "FREE FIRE",
                    wins = 48,
                    totalMatches = 58,
                    points = 2450,
                    winRate = "82.7%",
                    earnings = "₹2,450",
                    badgeTitle = "Grandmaster"
                ),
                LeaderboardPlayer(
                    id = "p2",
                    rank = 2,
                    username = "Godlike_Aman",
                    playerId = "MH-88192",
                    game = "BGMI",
                    wins = 44,
                    totalMatches = 55,
                    points = 2180,
                    winRate = "80.0%",
                    earnings = "₹2,100",
                    badgeTitle = "Conqueror"
                ),
                LeaderboardPlayer(
                    id = "p3",
                    rank = 3,
                    username = "ShadowSniper",
                    playerId = "MH-77103",
                    game = "FREE FIRE",
                    wins = 39,
                    totalMatches = 50,
                    points = 1950,
                    winRate = "78.0%",
                    earnings = "₹1,850",
                    badgeTitle = "Heroic"
                ),
                LeaderboardPlayer(
                    id = "p4",
                    rank = 4,
                    username = "ApexTitan_BG",
                    playerId = "MH-66291",
                    game = "BGMI",
                    wins = 33,
                    totalMatches = 45,
                    points = 1680,
                    winRate = "73.3%",
                    earnings = "₹1,450",
                    badgeTitle = "Ace Dominator"
                ),
                LeaderboardPlayer(
                    id = "p5",
                    rank = 5,
                    username = "ThunderStorm_FF",
                    playerId = "MH-55201",
                    game = "FREE FIRE",
                    wins = 28,
                    totalMatches = 40,
                    points = 1420,
                    winRate = "70.0%",
                    earnings = "₹1,200",
                    badgeTitle = "Master"
                ),
                LeaderboardPlayer(
                    id = "p6",
                    rank = 6,
                    username = "BlazeEagle",
                    playerId = "MH-44129",
                    game = "BGMI",
                    wins = 24,
                    totalMatches = 36,
                    points = 1250,
                    winRate = "66.7%",
                    earnings = "₹980",
                    badgeTitle = "Ace"
                ),
                LeaderboardPlayer(
                    id = "user",
                    rank = 7,
                    username = currentUserName,
                    playerId = currentUserPlayerId,
                    game = "FREE FIRE",
                    wins = userWins,
                    totalMatches = userWins + 2,
                    points = userPoints,
                    winRate = "60.0%",
                    earnings = "₹${userWins * 40}",
                    badgeTitle = "Elite Scout",
                    isCurrentUser = true
                ),
                LeaderboardPlayer(
                    id = "p8",
                    rank = 8,
                    username = "GhostRider_FF",
                    playerId = "MH-33812",
                    game = "FREE FIRE",
                    wins = 18,
                    totalMatches = 30,
                    points = 920,
                    winRate = "60.0%",
                    earnings = "₹720",
                    badgeTitle = "Diamond"
                ),
                LeaderboardPlayer(
                    id = "p9",
                    rank = 9,
                    username = "Kratos_BGMI",
                    playerId = "MH-22910",
                    game = "BGMI",
                    wins = 15,
                    totalMatches = 28,
                    points = 810,
                    winRate = "53.5%",
                    earnings = "₹580",
                    badgeTitle = "Crown"
                ),
                LeaderboardPlayer(
                    id = "p10",
                    rank = 10,
                    username = "SilentAssassin",
                    playerId = "MH-11928",
                    game = "FREE FIRE",
                    wins = 12,
                    totalMatches = 24,
                    points = 690,
                    winRate = "50.0%",
                    earnings = "₹450",
                    badgeTitle = "Platinum"
                )
            )

            basePlayers.sortedByDescending { it.points }
                .mapIndexed { index, player -> player.copy(rank = index + 1) }
        }
    }
}
