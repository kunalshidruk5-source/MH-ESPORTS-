package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.CoinTransactionEntity
import com.example.data.model.LeaderboardPlayer
import com.example.data.model.TournamentEntity
import com.example.data.model.UserProfileEntity
import com.example.data.repository.MhEsportsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class BottomNavTab {
    PLAY,
    MATCHES,
    LEADERBOARD,
    COINS,
    PROFILE
}

sealed class SubScreen {
    data class GameTournamentList(val game: String) : SubScreen()
    data class TournamentDetails(val tournamentId: String) : SubScreen()
    data class Payment(val tournamentId: String) : SubScreen()
    object Settings : SubScreen()
}

class MhEsportsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MhEsportsRepository

    val allTournaments: StateFlow<List<TournamentEntity>>
    val userProfile: StateFlow<UserProfileEntity?>
    val allTransactions: StateFlow<List<CoinTransactionEntity>>
    val leaderboardPlayers: StateFlow<List<LeaderboardPlayer>>

    private val _currentTab = MutableStateFlow(BottomNavTab.PLAY)
    val currentTab: StateFlow<BottomNavTab> = _currentTab.asStateFlow()

    private val _subScreenStack = MutableStateFlow<List<SubScreen>>(emptyList())
    val currentSubScreen: StateFlow<SubScreen?> = MutableStateFlow<SubScreen?>(null)
    private val _currentSubScreen = MutableStateFlow<SubScreen?>(null)

    // Current selected tournament for details/payment
    private val _selectedTournamentId = MutableStateFlow<String?>(null)
    val selectedTournamentId: StateFlow<String?> = _selectedTournamentId.asStateFlow()

    // Temporary screenshot attachment for payment
    private val _paymentScreenshotUri = MutableStateFlow<String?>(null)
    val paymentScreenshotUri: StateFlow<String?> = _paymentScreenshotUri.asStateFlow()

    // Pull to refresh states
    private val _isRefreshingMatches = MutableStateFlow(false)
    val isRefreshingMatches: StateFlow<Boolean> = _isRefreshingMatches.asStateFlow()

    private val _isRefreshingLeaderboard = MutableStateFlow(false)
    val isRefreshingLeaderboard: StateFlow<Boolean> = _isRefreshingLeaderboard.asStateFlow()

    // Notification / Toast / Dialog messages
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    private val _paymentSuccessDialogTournament = MutableStateFlow<TournamentEntity?>(null)
    val paymentSuccessDialogTournament: StateFlow<TournamentEntity?> = _paymentSuccessDialogTournament.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = MhEsportsRepository(database.mhEsportsDao())

        allTournaments = repository.allTournaments
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        userProfile = repository.userProfile
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

        allTransactions = repository.allTransactions
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        leaderboardPlayers = repository.getLeaderboardPlayers()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }

    fun selectTab(tab: BottomNavTab) {
        _currentTab.value = tab
        _subScreenStack.value = emptyList()
        _currentSubScreen.value = null
    }

    fun getActiveSubScreen(): StateFlow<SubScreen?> = _currentSubScreen

    fun navigateToSubScreen(subScreen: SubScreen) {
        val updated = _subScreenStack.value.toMutableList()
        updated.add(subScreen)
        _subScreenStack.value = updated
        _currentSubScreen.value = subScreen
    }

    fun navigateBack(): Boolean {
        val current = _subScreenStack.value
        if (current.isNotEmpty()) {
            val updated = current.toMutableList()
            updated.removeAt(updated.size - 1)
            _subScreenStack.value = updated
            _currentSubScreen.value = updated.lastOrNull()
            return true
        }
        return false
    }

    fun openGameTournaments(game: String) {
        navigateToSubScreen(SubScreen.GameTournamentList(game))
    }

    fun openTournamentDetails(tournamentId: String) {
        _selectedTournamentId.value = tournamentId
        navigateToSubScreen(SubScreen.TournamentDetails(tournamentId))
    }

    fun openPaymentScreen(tournamentId: String) {
        _selectedTournamentId.value = tournamentId
        _paymentScreenshotUri.value = null
        navigateToSubScreen(SubScreen.Payment(tournamentId))
    }

    fun openSettings() {
        navigateToSubScreen(SubScreen.Settings)
    }

    fun setPaymentScreenshotUri(uri: Uri?) {
        _paymentScreenshotUri.value = uri?.toString()
    }

    fun submitTournamentPaymentDone(tournamentId: String) {
        viewModelScope.launch {
            val tournament = allTournaments.value.find { it.id == tournamentId }
            repository.joinTournamentWithUpiSubmission(
                tournamentId = tournamentId,
                screenshotUri = _paymentScreenshotUri.value
            )
            _paymentSuccessDialogTournament.value = tournament
            _uiMessage.value = "Payment submitted! Registered for ${tournament?.title}."
        }
    }

    fun joinTournamentDirectlyWithCoins(tournamentId: String) {
        viewModelScope.launch {
            val success = repository.joinTournamentWithCoins(tournamentId)
            val tournament = allTournaments.value.find { it.id == tournamentId }
            if (success) {
                _paymentSuccessDialogTournament.value = tournament
                _uiMessage.value = "Joined successfully using Coins! Room details unlocked."
            } else {
                _uiMessage.value = "Insufficient coins! Please add coins or pay via UPI."
            }
        }
    }

    fun dismissPaymentSuccessDialog() {
        val tournament = _paymentSuccessDialogTournament.value
        _paymentSuccessDialogTournament.value = null
        // Navigate to MATCHES tab so user sees joined match and room details immediately
        selectTab(BottomNavTab.MATCHES)
    }

    fun submitCoinPurchase(amount: Int, screenshotUri: Uri?) {
        viewModelScope.launch {
            repository.submitCoinPurchase(amount, screenshotUri?.toString())
            _uiMessage.value = "Coin request of $amount Coins submitted successfully!"
        }
    }

    fun updateCustomQr(uri: Uri?) {
        viewModelScope.launch {
            repository.updateCustomQrUri(uri?.toString())
            _uiMessage.value = "Custom QR updated successfully!"
        }
    }

    fun updateProfile(username: String, ffUid: String, bgmiId: String) {
        viewModelScope.launch {
            repository.updateProfile(username, ffUid, bgmiId)
            _uiMessage.value = "Profile updated successfully!"
        }
    }

    fun refreshMatches() {
        viewModelScope.launch {
            _isRefreshingMatches.value = true
            kotlinx.coroutines.delay(800)
            _isRefreshingMatches.value = false
            _uiMessage.value = "Matches & Room status updated!"
        }
    }

    fun refreshLeaderboard() {
        viewModelScope.launch {
            _isRefreshingLeaderboard.value = true
            kotlinx.coroutines.delay(800)
            _isRefreshingLeaderboard.value = false
            _uiMessage.value = "Leaderboard rankings refreshed!"
        }
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }
}
