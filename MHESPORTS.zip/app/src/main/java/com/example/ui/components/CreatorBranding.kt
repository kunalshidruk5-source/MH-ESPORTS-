package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextWhite

/**
 * Creator branding badge that MUST be positioned in the upper-right corner of every screen.
 * Text must be exactly: "𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐁𝐘 𝐊𝐔𝐍𝐀𝐋 𝐒𝐇𝐈𝐃𝐑𝐔𝐊"
 */
@Composable
fun CreatorBrandingBadge(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .testTag("creator_branding_upper_right")
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color(0xFFFF1E4D).copy(alpha = 0.8f),
                        Color(0xFFFF8099).copy(alpha = 0.5f)
                    )
                ),
                shape = RoundedCornerShape(8.dp)
            ),
        shape = RoundedCornerShape(8.dp),
        color = Color(0x33FF1E4D),
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(NeonRed, CircleShape)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐁𝐘 𝐊𝐔𝐍𝐀𝐋 𝐒𝐇𝐈𝐃𝐑𝐔𝐊",
                color = TextWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.3.sp
            )
        }
    }
}

/**
 * Standard Header for MH ESPORTS screens.
 * Guarantees that "𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐁𝐘 𝐊𝐔𝐍𝐀𝐋 𝐒𝐇𝐈𝐃𝐑𝐔𝐊" is placed in the upper-right corner on every screen.
 */
@Composable
fun MhEsportsScreenHeader(
    title: String = "MH ESPORTS",
    subtitle: String? = null,
    onBackClick: (() -> Unit)? = null,
    coinBalance: Int? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkCharcoal)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Top row with title/back on left, and creator branding strictly in the UPPER-RIGHT corner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                if (onBackClick != null) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .testTag("back_button")
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                Column {
                    Text(
                        text = title,
                        color = TextWhite,
                        fontSize = if (onBackClick != null) 18.sp else 21.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            color = NeonRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Upper-right corner creator branding
            CreatorBrandingBadge()
        }

        // Optional Coin Pill Row if provided
        if (coinBalance != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0x33FFB800),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrize.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Coins",
                            tint = GoldPrize,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$coinBalance COINS",
                            color = GoldPrize,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}
