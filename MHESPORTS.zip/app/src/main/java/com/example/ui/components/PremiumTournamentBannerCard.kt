package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TournamentEntity
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

fun getTournamentBannerDrawable(game: String, format: String): Int {
    val isBgmi = game.contains("BGMI", ignoreCase = true)
    return when {
        isBgmi && format == "1v1" -> R.drawable.banner_bgmi_1v1_1790787420574
        isBgmi && format == "2v2" -> R.drawable.banner_bgmi_2v2_1790787438883
        isBgmi && format == "4v4" -> R.drawable.banner_bgmi_4v4_1790787456716
        !isBgmi && format == "1v1" -> R.drawable.banner_ff_1v1_1790787475593
        !isBgmi && format == "2v2" -> R.drawable.banner_ff_2v2_1790787488698
        !isBgmi && format == "4v4" -> R.drawable.banner_ff_4v4_1790787506313
        isBgmi -> R.drawable.bgmi_banner_1790777630382
        else -> R.drawable.ff_banner_1790777614820
    }
}

/**
 * Premium esports tournament banner card showcasing the 6 distinct tournament modes:
 * - BGMI 1v1
 * - BGMI 2v2
 * - BGMI 4v4
 * - FREE FIRE 1v1
 * - FREE FIRE 2v2
 * - FREE FIRE 4v4
 */
@Composable
fun PremiumTournamentBannerCard(
    tournament: TournamentEntity,
    onCardClick: () -> Unit,
    onJoinClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bannerDrawableRes = getTournamentBannerDrawable(tournament.game, tournament.format)
    val isBgmi = tournament.game.contains("BGMI", ignoreCase = true)
    val accentColor = if (isBgmi) NeonRed else Color(0xFFFF5722)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .testTag("tournament_banner_${tournament.game.lowercase()}_${tournament.format}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.5.dp,
            brush = Brush.horizontalGradient(
                listOf(
                    if (tournament.isJoined) StatusGreen else accentColor,
                    Color(0xFFFF3366).copy(alpha = 0.6f),
                    Color(0x33000000)
                )
            )
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Visual Hero Banner section with prominent uploaded art
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
            ) {
                // Main hero visual asset
                Image(
                    painter = painterResource(id = bannerDrawableRes),
                    contentDescription = "${tournament.game} ${tournament.format} Tournament Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Multi-layered cinema gradient for high contrast and readability
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    DarkCharcoal.copy(alpha = 0.55f),
                                    Color.Transparent,
                                    DarkCharcoal.copy(alpha = 0.95f)
                                )
                            )
                        )
                )

                // Top Badge Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Game & Mode Badges
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkCharcoal.copy(alpha = 0.85f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor)
                        ) {
                            Text(
                                text = if (isBgmi) "BGMI" else "FREE FIRE",
                                color = TextWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = accentColor
                        ) {
                            Text(
                                text = when (tournament.format) {
                                    "1v1" -> "1v1 SOLO"
                                    "2v2" -> "2v2 DUO"
                                    else -> "4v4 SQUAD"
                                },
                                color = TextWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Live / Joined Status
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (tournament.isJoined) StatusGreen.copy(alpha = 0.25f) else Color(0x33FF1E4D),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (tournament.isJoined) StatusGreen else NeonRed
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(if (tournament.isJoined) StatusGreen else NeonRed, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (tournament.isJoined) "JOINED" else "LIVE SCRIM",
                                color = if (tournament.isJoined) StatusGreen else TextWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                // Tournament Title Overlay at bottom of hero visual
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = tournament.title.uppercase(),
                        color = TextWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "${tournament.matchDate} • ${tournament.matchTime}",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Lower Esports Details & Action Section
            Surface(
                color = Color(0xFF12131D),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Prize Pool & Entry Details Strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Winner Prize Badge
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0x22FFB800),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrize.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = GoldPrize,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "PRIZE POOL",
                                        color = GoldPrize.copy(alpha = 0.8f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = tournament.winnerPrize,
                                        color = GoldPrize,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }

                        // Entry Fee
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0x22FF1E4D),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = NeonRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "ENTRY FEE",
                                        color = NeonRed.copy(alpha = 0.8f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${tournament.entryCoins} Coins",
                                        color = TextWhite,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }

                        // Total Entry Pool
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "TOTAL POOL",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${tournament.totalEntryCoins} Coins",
                                color = TextWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action Buttons: "VIEW DETAILS" & "JOIN MATCH"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onCardClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_details_${tournament.id}"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x44FFFFFF))
                        ) {
                            Text(
                                text = "DETAILS",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = {
                                if (tournament.isJoined) {
                                    onCardClick()
                                } else {
                                    onJoinClick()
                                }
                            },
                            modifier = Modifier
                                .weight(1.3f)
                                .height(44.dp)
                                .testTag("btn_join_${tournament.id}"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tournament.isJoined) StatusGreen else NeonRed
                            )
                        ) {
                            Icon(
                                imageVector = if (tournament.isJoined) Icons.Default.LockOpen else Icons.Default.Bolt,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = TextWhite
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (tournament.isJoined) "ROOM UNLOCKED" else "JOIN TOURNAMENT",
                                color = TextWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
