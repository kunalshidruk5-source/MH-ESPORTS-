package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

const val OFFICIAL_UPI_ID = "kunalshidruk07@oksbii"

@Composable
fun ReusableQrPayment(
    amountText: String,
    coinAmountText: String? = null,
    customQrUri: String? = null,
    onCustomQrUploaded: ((Uri) -> Unit)? = null,
    screenshotUri: String? = null,
    onScreenshotUploaded: ((Uri) -> Unit)? = null,
    onPaymentDoneClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var copiedToClipboard by remember { mutableStateOf(false) }

    // Custom QR image picker
    val qrImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onCustomQrUploaded?.invoke(uri)
            Toast.makeText(context, "Custom QR Code uploaded successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    // Payment Screenshot picker
    val screenshotPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onScreenshotUploaded?.invoke(uri)
            Toast.makeText(context, "Payment screenshot attached!", Toast.LENGTH_SHORT).show()
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("reusable_qr_payment_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = GamingSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x22FF1E4D))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode2,
                    contentDescription = null,
                    tint = NeonRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SCAN & PAY VIA UPI",
                    color = NeonRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // QR Code Box - Pure white background card with ample breathing room for scanning
            Surface(
                modifier = Modifier
                    .size(240.dp)
                    .aspectRatio(1f)
                    .testTag("qr_code_display_box"),
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                shadowElevation = 8.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (!customQrUri.isNullOrEmpty()) {
                        // Render user-uploaded custom QR code
                        Image(
                            painter = rememberAsyncImagePainter(model = customQrUri),
                            contentDescription = "Custom Payment QR Code",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        // High-fidelity fallback simulated vector QR code graphic with "PAYMENT QR" banner
                        SimulatedQrCodeView(modifier = Modifier.fillMaxSize())
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Optional button to upload/switch custom QR image
            if (onCustomQrUploaded != null) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            qrImagePicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Change QR",
                        tint = GoldPrize,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (customQrUri != null) "Change Custom QR" else "Upload Custom QR Code",
                        color = GoldPrize,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Payment Amount Display
            Text(
                text = "Amount to Pay: $amountText",
                color = TextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )
            if (coinAmountText != null) {
                Text(
                    text = "Equivalent: $coinAmountText",
                    color = GoldPrize,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // UPI ID Display Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("upi_id_container"),
                shape = RoundedCornerShape(12.dp),
                color = GamingSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "UPI ID",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = OFFICIAL_UPI_ID,
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("UPI ID", OFFICIAL_UPI_ID)
                                clipboard.setPrimaryClip(clip)
                                copiedToClipboard = true
                                Toast.makeText(context, "UPI ID copied to clipboard!", Toast.LENGTH_SHORT).show()
                            }
                            .testTag("copy_upi_button"),
                        shape = RoundedCornerShape(8.dp),
                        color = if (copiedToClipboard) StatusGreen.copy(alpha = 0.2f) else Color(0x33FF1E4D),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (copiedToClipboard) StatusGreen else NeonRed.copy(alpha = 0.6f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (copiedToClipboard) Icons.Default.CheckCircle else Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = if (copiedToClipboard) StatusGreen else NeonRed,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (copiedToClipboard) "COPIED" else "COPY",
                                color = if (copiedToClipboard) StatusGreen else TextWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action: PAY NOW Button (Launches UPI Apps if installed)
            Button(
                onClick = {
                    val cleanAmount = amountText.replace(Regex("[^0-9.]"), "").ifEmpty { "10" }
                    val upiUri = Uri.parse("upi://pay?pa=$OFFICIAL_UPI_ID&pn=MH%20ESPORTS&am=$cleanAmount&cu=INR&tn=MH%20ESPORTS%20Entry")
                    val intent = Intent(Intent.ACTION_VIEW, upiUri)
                    try {
                        context.startActivity(Intent.createChooser(intent, "Pay via UPI App"))
                    } catch (e: Exception) {
                        Toast.makeText(context, "No UPI app detected. Please copy UPI ID $OFFICIAL_UPI_ID and pay via GPay/PhonePe.", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pay_now_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed)
            ) {
                Icon(
                    imageVector = Icons.Default.Payment,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PAY NOW (OPEN UPI APP)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Upload Screenshot Option
            OutlinedButton(
                onClick = {
                    screenshotPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("upload_screenshot_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (screenshotUri != null) StatusGreen else TextWhite
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (screenshotUri != null) StatusGreen else Color(0x66FFFFFF)
                )
            ) {
                Icon(
                    imageVector = if (screenshotUri != null) Icons.Default.CheckCircle else Icons.Default.UploadFile,
                    contentDescription = null,
                    tint = if (screenshotUri != null) StatusGreen else TextWhite,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (screenshotUri != null) "SCREENSHOT ATTACHED ✓" else "UPLOAD PAYMENT SCREENSHOT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Thumbnail preview if screenshot selected
            if (screenshotUri != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(GamingSurfaceVariant)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(model = screenshotUri),
                        contentDescription = "Screenshot preview",
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Screenshot ready for admin verification",
                        color = StatusGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // PAYMENT DONE button
            Button(
                onClick = onPaymentDoneClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("payment_done_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853))
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = TextWhite,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PAYMENT DONE",
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Note: Submission will register your entry. Match custom Room ID and Password will be immediately accessible in Matches.",
                color = TextMuted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                lineHeight = 15.sp
            )
        }
    }
}

/**
 * High quality vector simulated QR code graphic with "PAYMENT QR" text and realistic QR patterns.
 */
@Composable
fun SimulatedQrCodeView(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("placeholder_qr_code"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Corner squares (Standard QR code positioning markers)
            fun drawMarker(x: Float, y: Float, markerSize: Float) {
                // Outer square
                drawRoundRect(
                    color = Color.Black,
                    topLeft = Offset(x, y),
                    size = Size(markerSize, markerSize),
                    cornerRadius = CornerRadius(8f, 8f),
                    style = Stroke(width = markerSize * 0.16f)
                )
                // Inner solid square
                val innerOffset = markerSize * 0.28f
                val innerSize = markerSize * 0.44f
                drawRoundRect(
                    color = Color.Black,
                    topLeft = Offset(x + innerOffset, y + innerOffset),
                    size = Size(innerSize, innerSize),
                    cornerRadius = CornerRadius(4f, 4f)
                )
            }

            val markerSize = canvasWidth * 0.26f
            // Top-left marker
            drawMarker(0f, 0f, markerSize)
            // Top-right marker
            drawMarker(canvasWidth - markerSize, 0f, markerSize)
            // Bottom-left marker
            drawMarker(0f, canvasHeight - markerSize, markerSize)

            // Synthetic dense QR grid matrix elements
            val step = canvasWidth / 19f
            for (col in 0 until 19) {
                for (row in 0 until 19) {
                    val inTopLeft = col < 6 && row < 6
                    val inTopRight = col > 12 && row < 6
                    val inBottomLeft = col < 6 && row > 12
                    val inCenterBanner = col in 6..12 && row in 7..11

                    if (!inTopLeft && !inTopRight && !inBottomLeft && !inCenterBanner) {
                        // Pseudo-random deterministic bits based on indices
                        val hash = (col * 31 + row * 17 + (col xor row) * 7) % 11
                        if (hash < 6) {
                            drawRoundRect(
                                color = Color.Black,
                                topLeft = Offset(col * step + step * 0.15f, row * step + step * 0.15f),
                                size = Size(step * 0.7f, step * 0.7f),
                                cornerRadius = CornerRadius(2f, 2f)
                            )
                        }
                    }
                }
            }
        }

        // Center "PAYMENT QR" and emblem badge
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = DarkCharcoal,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, NeonRed),
            modifier = Modifier.padding(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "MH ESPORTS",
                    color = NeonRed,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "PAYMENT QR",
                    color = TextWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}
