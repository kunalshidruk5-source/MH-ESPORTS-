package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CoinTransactionEntity
import com.example.data.model.UserProfileEntity
import com.example.ui.components.MhEsportsScreenHeader
import com.example.ui.components.ReusableQrPayment
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CoinsScreen(
    userProfile: UserProfileEntity?,
    transactions: List<CoinTransactionEntity>,
    onCustomQrUploaded: (Uri) -> Unit,
    onSubmitCoinPurchase: (Int, Uri?) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedPackageAmount by remember { mutableStateOf(50) } // Default 50 Coins
    var screenshotUri by remember { mutableStateOf<Uri?>(null) }
    val userCoins = userProfile?.coinsBalance ?: 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCharcoal)
            .testTag("coins_screen")
    ) {
        // Upper-right creator branding guaranteed
        MhEsportsScreenHeader(
            title = "COINS WALLET",
            subtitle = "ESPORTS CREDITS"
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Coin Balance Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = GamingSurface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrize.copy(alpha = 0.8f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0x33FFB800),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrize)
                        ) {
                            Box(
                                modifier = Modifier.size(60.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = GoldPrize,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "$userCoins",
                            color = TextWhite,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "CURRENT COIN BALANCE",
                            color = GoldPrize,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Rate conversion badge
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GamingSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
                        ) {
                            Text(
                                text = "1 Rupee = 1 Coin",
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Coin Packages Section
            item {
                Text(
                    text = "SELECT COIN PACKAGE",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(50, 100, 250, 500).forEach { coins ->
                        val isSelected = selectedPackageAmount == coins
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedPackageAmount = coins }
                                .testTag("coin_pkg_$coins"),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0x33FF1E4D) else GamingSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (isSelected) NeonRed else Color(0x22FFFFFF)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "$coins",
                                    color = if (isSelected) NeonRed else TextWhite,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Coins",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isSelected) NeonRed else Color(0x33FFFFFF)
                                ) {
                                    Text(
                                        text = "₹$coins",
                                        color = TextWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Reusable QR Payment for Buying Coins
            item {
                Text(
                    text = "ADD COINS VIA UPI QR",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }

            item {
                ReusableQrPayment(
                    amountText = "₹$selectedPackageAmount",
                    coinAmountText = "$selectedPackageAmount Coins",
                    customQrUri = userProfile?.customQrUri,
                    onCustomQrUploaded = onCustomQrUploaded,
                    screenshotUri = screenshotUri?.toString(),
                    onScreenshotUploaded = { uri -> screenshotUri = uri },
                    onPaymentDoneClick = {
                        onSubmitCoinPurchase(selectedPackageAmount, screenshotUri)
                        screenshotUri = null
                    }
                )
            }

            // Coin Transaction History
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = GoldPrize,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "COIN TRANSACTION HISTORY",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            if (transactions.isEmpty()) {
                item {
                    Text(
                        text = "No coin transactions yet.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    CoinTransactionItem(transaction = tx)
                }
            }
        }
    }
}

@Composable
fun CoinTransactionItem(transaction: CoinTransactionEntity) {
    val isReceived = transaction.type == "RECEIVED"
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val dateStr = remember(transaction.timestamp) { dateFormat.format(Date(transaction.timestamp)) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tx_item_${transaction.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = GamingSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x22FFFFFF))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = if (isReceived) StatusGreen.copy(alpha = 0.2f) else NeonRed.copy(alpha = 0.2f)
                ) {
                    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isReceived) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                            contentDescription = null,
                            tint = if (isReceived) StatusGreen else NeonRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = transaction.title,
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$dateStr • ${transaction.status}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Text(
                text = "${if (isReceived) "+" else "-"}${transaction.amount} Coins",
                color = if (isReceived) StatusGreen else NeonRed,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}
