package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TournamentEntity
import com.example.ui.components.MhEsportsScreenHeader
import com.example.ui.components.PremiumTournamentBannerCard
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun GameTournamentListScreen(
    game: String,
    tournaments: List<TournamentEntity>,
    onBackClick: () -> Unit,
    onTournamentClick: (String) -> Unit,
    onJoinMatchClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val gameTournaments = tournaments.filter { it.game.equals(game, ignoreCase = true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCharcoal)
            .testTag("game_tournament_list_screen")
    ) {
        // Upper-right creator branding guaranteed
        MhEsportsScreenHeader(
            title = "$game TOURNAMENTS",
            subtitle = "OFFICIAL MH ESPORTS SCRIMS",
            onBackClick = onBackClick
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Price structure summary banner
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = GamingSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "OFFICIAL PRICING & PRIZE POOL",
                            color = NeonRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• 1v1: Entry 10 Coins/player | Total Entry 20 Coins | Winner Prize: ₹15\n" +
                                    "• 2v2: Entry 10 Coins/player | Total Entry 40 Coins | Winning Team: ₹40\n" +
                                    "• 4v4: Entry 10 Coins/player | Total Entry 80 Coins | Winning Team: ₹70",
                            color = TextWhite,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            item {
                Text(
                    text = "AVAILABLE MATCHES (${gameTournaments.size})",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            items(gameTournaments, key = { it.id }) { tournament ->
                PremiumTournamentBannerCard(
                    tournament = tournament,
                    onCardClick = { onTournamentClick(tournament.id) },
                    onJoinClick = { onJoinMatchClick(tournament.id) }
                )
            }
        }
    }
}
