package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TournamentEntity
import com.example.data.model.UserProfileEntity
import com.example.ui.components.MhEsportsScreenHeader
import com.example.ui.components.PremiumTournamentBannerCard
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun HomeScreen(
    tournaments: List<TournamentEntity>,
    userProfile: UserProfileEntity?,
    onSelectGame: (String) -> Unit,
    onTournamentClick: (String) -> Unit,
    onJoinMatchClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedGameTab by remember { mutableStateOf<String?>(null) } // null for all, "BGMI", "FREE FIRE"
    var selectedFormatFilter by remember { mutableStateOf<String?>(null) } // null for all, "1v1", "2v2", "4v4"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCharcoal)
    ) {
        // App Header with Creator Branding strictly in upper-right corner
        MhEsportsScreenHeader(
            title = "MH ESPORTS",
            subtitle = "OFFICIAL TOURNAMENTS",
            coinBalance = userProfile?.coinsBalance
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Choose Your Game
            item {
                Text(
                    text = "SELECT GAME",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            // Two Large Clickable Game Cards: FREE FIRE and BGMI
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GameSelectionCard(
                        gameTitle = "FREE FIRE",
                        subtitle = "BATTLE ROYALE",
                        activeMatches = tournaments.count { it.game == "FREE FIRE" },
                        bannerRes = R.drawable.ff_banner_1790777614820,
                        accentColor = Color(0xFFFF5722),
                        onClick = { onSelectGame("FREE FIRE") },
                        modifier = Modifier.weight(1f)
                    )

                    GameSelectionCard(
                        gameTitle = "BGMI",
                        subtitle = "BATTLEGROUNDS",
                        activeMatches = tournaments.count { it.game == "BGMI" },
                        bannerRes = R.drawable.bgmi_banner_1790777630382,
                        accentColor = Color(0xFFFF1E4D),
                        onClick = { onSelectGame("BGMI") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Section 2: Choose Your Match
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "OFFICIAL TOURNAMENT BANNERS",
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "BGMI & Free Fire • 1v1, 2v2 & 4v4 Scrims",
                            color = NeonRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Game Tabs (ALL, BGMI, FREE FIRE)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(null to "ALL (6)", "BGMI" to "BGMI (3)", "FREE FIRE" to "FREE FIRE (3)").forEach { (gameKey, label) ->
                        val isSelected = selectedGameTab == gameKey
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedGameTab = gameKey }
                                .testTag("tab_game_${label.lowercase().replace(" ", "_")}"),
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) NeonRed else GamingSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) NeonRed else Color(0x33FFFFFF)
                            )
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            // Quick Format Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(null to "ALL MODES", "1v1" to "1v1 SOLO", "2v2" to "2v2 DUO", "4v4" to "4v4 SQUAD").forEach { (formatKey, label) ->
                        val isSelected = selectedFormatFilter == formatKey
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { selectedFormatFilter = formatKey }
                                .testTag("filter_chip_${label.lowercase().replace(" ", "_")}"),
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) Color(0x33FF1E4D) else GamingSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) NeonRed else Color(0x22FFFFFF)
                            )
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) NeonRed else TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Filtered Tournaments List - Displays the 6 Separate Premium Banners
            val displayList = tournaments.filter { tournament ->
                (selectedGameTab == null || tournament.game.equals(selectedGameTab, ignoreCase = true)) &&
                (selectedFormatFilter == null || tournament.format == selectedFormatFilter)
            }

            items(displayList, key = { it.id }) { tournament ->
                PremiumTournamentBannerCard(
                    tournament = tournament,
                    onCardClick = { onTournamentClick(tournament.id) },
                    onJoinClick = { onJoinMatchClick(tournament.id) }
                )
            }
        }
    }
}

/**
 * Large clickable Game Card for FREE FIRE and BGMI
 */
@Composable
fun GameSelectionCard(
    gameTitle: String,
    subtitle: String,
    activeMatches: Int,
    bannerRes: Int,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(180.dp)
            .clickable(onClick = onClick)
            .testTag("game_card_${gameTitle.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GamingSurface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, accentColor.copy(alpha = 0.6f))
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background Banner Image
            Image(
                painter = painterResource(id = bannerRes),
                contentDescription = gameTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Dark gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Transparent,
                                DarkCharcoal.copy(alpha = 0.6f),
                                DarkCharcoal.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // Live tag badge at top
            Surface(
                modifier = Modifier
                    .padding(8.dp)
                    .align(Alignment.TopStart),
                shape = RoundedCornerShape(8.dp),
                color = DarkCharcoal.copy(alpha = 0.8f),
                border = androidx.compose.foundation.BorderStroke(1.dp, accentColor)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(StatusGreen, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LIVE",
                        color = StatusGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Card Content Info at bottom
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
            ) {
                Text(
                    text = gameTitle,
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "$activeMatches Matches Available",
                    color = accentColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Premium Tournament Card component
 */
@Composable
fun TournamentCard(
    tournament: TournamentEntity,
    onCardClick: () -> Unit,
    onJoinClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .testTag("tournament_card_${tournament.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GamingSurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (tournament.isJoined) StatusGreen.copy(alpha = 0.8f) else NeonRed.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Top row: Game & Format Badges, Joined status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Game badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (tournament.game == "FREE FIRE") Color(0x33FF5722) else Color(0x33FF1E4D),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (tournament.game == "FREE FIRE") Color(0xFFFF5722) else NeonRed
                        )
                    ) {
                        Text(
                            text = tournament.game,
                            color = TextWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Format badge (1v1, 2v2, 4v4)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = GamingSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
                    ) {
                        Text(
                            text = tournament.format,
                            color = GoldPrize,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Joined Badge or Room Lock status
                if (tournament.isJoined) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusGreen.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusGreen)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = StatusGreen,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "JOINED",
                                color = StatusGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tournament.matchTime,
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = tournament.title,
                color = TextWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Price & Stats row
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = GamingSurfaceVariant
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Winner Prize
                    Column {
                        Text(
                            text = "WINNER PRIZE",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = GoldPrize,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = tournament.winnerPrize,
                                color = GoldPrize,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Entry fee per player
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "ENTRY FEE",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = NeonRed,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${tournament.entryCoins} Coins",
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Total Entry
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "TOTAL ENTRY",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${tournament.totalEntryCoins} Coins",
                            color = TextWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: "VIEW DETAILS" and "JOIN MATCH"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCardClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("view_details_${tournament.id}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FFFFFF))
                ) {
                    Text(
                        text = "VIEW DETAILS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        if (tournament.isJoined) {
                            onCardClick()
                        } else {
                            onJoinClick()
                        }
                    },
                    modifier = Modifier
                        .weight(1.2f)
                        .height(42.dp)
                        .testTag("join_match_${tournament.id}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (tournament.isJoined) StatusGreen else NeonRed
                    )
                ) {
                    Icon(
                        imageVector = if (tournament.isJoined) Icons.Default.LockOpen else Icons.Default.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (tournament.isJoined) "ROOM DETAILS" else "JOIN MATCH",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
