package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LeaderboardPlayer
import com.example.ui.components.MhEsportsScreenHeader
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

val SilverColor = Color(0xFFC0C0C0)
val BronzeColor = Color(0xFFCD7F32)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaderboardScreen(
    players: List<LeaderboardPlayer>,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedGameFilter by remember { mutableStateOf<String?>(null) } // null for ALL, "FREE FIRE", "BGMI"
    var selectedPlayerForDetails by remember { mutableStateOf<LeaderboardPlayer?>(null) }

    val filteredPlayers = remember(players, selectedGameFilter) {
        val list = if (selectedGameFilter == null) {
            players
        } else {
            players.filter { it.game.equals(selectedGameFilter, ignoreCase = true) }
        }
        // Recalculate ranks for filtered list
        list.sortedByDescending { it.points }.mapIndexed { index, p -> p.copy(rank = index + 1) }
    }

    val top1 = filteredPlayers.getOrNull(0)
    val top2 = filteredPlayers.getOrNull(1)
    val top3 = filteredPlayers.getOrNull(2)
    val currentUserEntry = filteredPlayers.find { it.isCurrentUser }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCharcoal)
            .testTag("leaderboard_screen")
    ) {
        // Upper-right creator branding guaranteed: "𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐁𝐘 𝐊𝐔𝐍𝐀𝐋 𝐒𝐇𝐈𝐃𝐑𝐔𝐊"
        MhEsportsScreenHeader(
            title = "LEADERBOARD",
            subtitle = "TOP ESPORTS CHAMPIONS"
        )

        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Game Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(null to "ALL GAMES", "FREE FIRE" to "FREE FIRE", "BGMI" to "BGMI").forEach { (filterKey, label) ->
                        val isSelected = selectedGameFilter == filterKey
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { selectedGameFilter = filterKey }
                                .testTag("lb_filter_${label.lowercase().replace(" ", "_")}"),
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) NeonRed else GamingSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) NeonRed else Color(0x33FFFFFF)
                            )
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
            }

            // Top 3 Podium
            if (filteredPlayers.size >= 3 && top1 != null && top2 != null && top3 != null) {
                item {
                    PodiumSection(
                        top1 = top1,
                        top2 = top2,
                        top3 = top3,
                        onPlayerClick = { selectedPlayerForDetails = it }
                    )
                }
            }

            // Pinned Current User Rank Card
            if (currentUserEntry != null) {
                item {
                    CurrentUserRankCard(
                        player = currentUserEntry,
                        onClick = { selectedPlayerForDetails = currentUserEntry }
                    )
                }
            }

            // Header for all rankings
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GLOBAL RANKINGS",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Season 1 Scrims",
                        color = NeonRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Players Ranking List
            items(filteredPlayers, key = { it.id }) { player ->
                LeaderboardPlayerCard(
                    player = player,
                    onClick = { selectedPlayerForDetails = player }
                )
            }
        }
        }
    }

    // Player Details Dialog
    if (selectedPlayerForDetails != null) {
        val player = selectedPlayerForDetails!!
        AlertDialog(
            onDismissRequest = { selectedPlayerForDetails = null },
            containerColor = GamingSurface,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = CircleShape,
                        color = when (player.rank) {
                            1 -> GoldPrize.copy(alpha = 0.2f)
                            2 -> SilverColor.copy(alpha = 0.2f)
                            3 -> BronzeColor.copy(alpha = 0.2f)
                            else -> Color(0x33FF1E4D)
                        },
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            when (player.rank) {
                                1 -> GoldPrize
                                2 -> SilverColor
                                3 -> BronzeColor
                                else -> NeonRed
                            }
                        )
                    ) {
                        Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = "#${player.rank}",
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = player.username,
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "${player.badgeTitle} • ${player.playerId}",
                            color = GoldPrize,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("TOTAL POINTS", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text("${player.points}", color = GoldPrize, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("MATCH WINS", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text("${player.wins}", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("WIN RATE", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(player.winRate, color = StatusGreen, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Preferred Game:", color = TextMuted, fontSize = 12.sp)
                        Text(player.game, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Matches Played:", color = TextMuted, fontSize = 12.sp)
                        Text("${player.totalMatches}", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Estimated Earnings:", color = TextMuted, fontSize = 12.sp)
                        Text(player.earnings, color = GoldPrize, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedPlayerForDetails = null },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

/**
 * Top 3 Podium Component
 */
@Composable
fun PodiumSection(
    top1: LeaderboardPlayer,
    top2: LeaderboardPlayer,
    top3: LeaderboardPlayer,
    onPlayerClick: (LeaderboardPlayer) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("podium_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = GamingSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrize.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = GoldPrize,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SEASON 1 PODIUM CHAMPIONS",
                    color = GoldPrize,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Row containing 2nd, 1st, 3rd podium pillars
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // Rank 2 (Left)
                PodiumPillar(
                    player = top2,
                    rank = 2,
                    color = SilverColor,
                    height = 110.dp,
                    avatarSize = 52.dp,
                    onClick = { onPlayerClick(top2) },
                    modifier = Modifier.weight(1f)
                )

                // Rank 1 (Center - Tallest)
                PodiumPillar(
                    player = top1,
                    rank = 1,
                    color = GoldPrize,
                    height = 135.dp,
                    avatarSize = 64.dp,
                    onClick = { onPlayerClick(top1) },
                    modifier = Modifier.weight(1.15f)
                )

                // Rank 3 (Right)
                PodiumPillar(
                    player = top3,
                    rank = 3,
                    color = BronzeColor,
                    height = 95.dp,
                    avatarSize = 48.dp,
                    onClick = { onPlayerClick(top3) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun PodiumPillar(
    player: LeaderboardPlayer,
    rank: Int,
    color: Color,
    height: androidx.compose.ui.unit.Dp,
    avatarSize: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Crown or rank badge on top
        if (rank == 1) {
            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = "Champion",
                tint = GoldPrize,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(1.dp, color)
            ) {
                Text(
                    text = "#$rank",
                    color = color,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Avatar Box
        Box(
            modifier = Modifier
                .size(avatarSize)
                .border(2.dp, color, CircleShape)
                .padding(3.dp)
                .clip(CircleShape)
                .background(GamingSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = player.username,
                tint = color,
                modifier = Modifier.size(avatarSize * 0.6f)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = player.username,
            color = TextWhite,
            fontSize = if (rank == 1) 12.sp else 11.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
            textAlign = TextAlign.Center
        )

        Text(
            text = "${player.points} PTS",
            color = color,
            fontSize = if (rank == 1) 12.sp else 10.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Podium Pillar Base
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(height),
            shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp),
            color = GamingSurfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "#$rank",
                    color = color,
                    fontSize = if (rank == 1) 28.sp else 22.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "${player.wins} WINS",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Pinned Current User Ranking Card
 */
@Composable
fun CurrentUserRankCard(
    player: LeaderboardPlayer,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("current_user_rank_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GamingSurface),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            Brush.horizontalGradient(listOf(NeonRed, GoldPrize))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Rank Badge
                Surface(
                    shape = CircleShape,
                    color = Color(0x33FF1E4D),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, NeonRed)
                ) {
                    Box(modifier = Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "#${player.rank}",
                            color = TextWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = player.username,
                            color = TextWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = NeonRed
                        ) {
                            Text(
                                text = "YOU",
                                color = TextWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Text(
                        text = "${player.wins} Wins • ${player.badgeTitle}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${player.points} PTS",
                    color = GoldPrize,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Tap for stats",
                    color = StatusGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Standard Player Card in the Leaderboard List
 */
@Composable
fun LeaderboardPlayerCard(
    player: LeaderboardPlayer,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rankColor = when (player.rank) {
        1 -> GoldPrize
        2 -> SilverColor
        3 -> BronzeColor
        else -> if (player.isCurrentUser) NeonRed else TextMuted
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("player_row_${player.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (player.isCurrentUser) GamingSurfaceVariant else GamingSurface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (player.isCurrentUser) NeonRed.copy(alpha = 0.8f) else Color(0x22FFFFFF)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Rank number
                Box(
                    modifier = Modifier.width(32.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "#${player.rank}",
                        color = rankColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Avatar placeholder
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(GamingSurfaceVariant)
                        .border(1.dp, rankColor.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = rankColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = player.username,
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        if (player.isCurrentUser) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = NeonRed
                            ) {
                                Text(
                                    text = "YOU",
                                    color = TextWhite,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (player.game == "FREE FIRE") Color(0x33FF5722) else Color(0x33FF1E4D)
                        ) {
                            Text(
                                text = player.game,
                                color = if (player.game == "FREE FIRE") Color(0xFFFF5722) else NeonRed,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${player.wins} Wins • ${player.winRate}",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Points & Earnings
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${player.points} PTS",
                    color = GoldPrize,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = player.earnings,
                    color = StatusGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
