package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TournamentEntity
import com.example.data.model.UserProfileEntity
import com.example.ui.components.MhEsportsScreenHeader
import com.example.ui.components.ReusableQrPayment
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.GamingSurface
import com.example.ui.theme.GamingSurfaceVariant
import com.example.ui.theme.GoldPrize
import com.example.ui.theme.NeonRed
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun PaymentScreen(
    tournament: TournamentEntity,
    userProfile: UserProfileEntity?,
    paymentScreenshotUri: String?,
    onScreenshotUploaded: (Uri) -> Unit,
    onCustomQrUploaded: (Uri) -> Unit,
    onPayWithCoinsClick: () -> Unit,
    onPaymentDoneClick: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val userCoins = userProfile?.coinsBalance ?: 0
    val hasEnoughCoins = userCoins >= tournament.entryCoins

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCharcoal)
            .testTag("payment_screen")
    ) {
        // Upper-right creator branding guaranteed
        MhEsportsScreenHeader(
            title = "JOIN TOURNAMENT",
            subtitle = "PAYMENT & REGISTRATION",
            onBackClick = onBackClick
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Selected Match Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GamingSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "SELECTED MATCH",
                                    color = NeonRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "${tournament.game} ${tournament.format}",
                                    color = TextWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = GamingSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrize)
                            ) {
                                Text(
                                    text = "PRIZE: ${tournament.winnerPrize}",
                                    color = GoldPrize,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Entry Amount:",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "₹${tournament.entryCoins} (or ${tournament.entryCoins} Coins)",
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Your Coin Balance:",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "$userCoins Coins",
                                color = if (hasEnoughCoins) StatusGreen else NeonRed,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // OPTION 1: Pay Directly with Coin Balance
            if (hasEnoughCoins) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = GamingSurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, StatusGreen)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = GoldPrize,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "INSTANT COIN PAYMENT",
                                        color = StatusGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "You have $userCoins Coins available",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = onPayWithCoinsClick,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("pay_with_coins_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusGreen)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = TextWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "JOIN INSTANTLY (DEDUCT ${tournament.entryCoins} COINS)",
                                    color = TextWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(1.dp)
                                .background(Color(0x33FFFFFF))
                        )
                        Text(
                            text = "  OR PAY VIA UPI QR  ",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(1.dp)
                                .background(Color(0x33FFFFFF))
                        )
                    }
                }
            }

            // OPTION 2: Reusable UPI QR Payment Section
            item {
                ReusableQrPayment(
                    amountText = "₹${tournament.entryCoins}",
                    coinAmountText = "${tournament.entryCoins} Coins",
                    customQrUri = userProfile?.customQrUri,
                    onCustomQrUploaded = onCustomQrUploaded,
                    screenshotUri = paymentScreenshotUri,
                    onScreenshotUploaded = onScreenshotUploaded,
                    onPaymentDoneClick = onPaymentDoneClick
                )
            }
        }
    }
}
