package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonRed = Color(0xFFFF1E4D)
val NeonRedGlow = Color(0xFFFF3B65)
val DeepRed = Color(0xFFCC0835)
val DarkCharcoal = Color(0xFF0A0A0E)
val GamingSurface = Color(0xFF14151F)
val GamingSurfaceVariant = Color(0xFF1C1D2B)
val GamingSurfaceBorder = Color(0x33FF1E4D)
val GoldPrize = Color(0xFFFFB800)
val GoldPrizeGlow = Color(0xFFFFD54F)
val StatusGreen = Color(0xFF00E676)
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFA0A5BA)
val TextDarkMuted = Color(0xFF6B7280)
val DarkOverlay = Color(0x99000000)
