package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NeonRed,
    onPrimary = Color.White,
    primaryContainer = DeepRed,
    onPrimaryContainer = Color.White,
    secondary = GoldPrize,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF332600),
    onSecondaryContainer = GoldPrizeGlow,
    background = DarkCharcoal,
    onBackground = TextWhite,
    surface = GamingSurface,
    onSurface = TextWhite,
    surfaceVariant = GamingSurfaceVariant,
    onSurfaceVariant = TextMuted,
    outline = GamingSurfaceBorder,
    error = Color(0xFFFF5252),
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Always premium esports dark theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
